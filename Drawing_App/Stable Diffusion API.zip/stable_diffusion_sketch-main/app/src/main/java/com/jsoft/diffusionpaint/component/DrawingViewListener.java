package com.jsoft.diffusionpaint.component;

public interface DrawingViewListener {
    void onEyedropperResult(int color);
}
