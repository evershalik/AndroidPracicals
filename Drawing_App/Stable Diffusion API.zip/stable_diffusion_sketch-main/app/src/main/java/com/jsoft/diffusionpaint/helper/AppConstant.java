package com.jsoft.diffusionpaint.helper;

public class AppConstant {

    // Number of columns of Grid View
    public static final int NUM_OF_COLUMNS = 5;

    // Gridview image padding
    public static final int GRID_PADDING = 8; // in dp

}